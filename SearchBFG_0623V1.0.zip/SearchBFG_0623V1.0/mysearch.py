from SPARQLWrapper import SPARQLWrapper, JSON

def searchbooks(keyInfo):
    sparql = SPARQLWrapper("http://dbpedia.org/sparql")
    sparql.setQuery(("""
    prefix rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>
    prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> 
    prefix dbo: <http://dbpedia.org/ontology/>
    prefix dbp: <http://dbpedia.org/property/>
    prefix foaf: <http://xmlns.com/foaf/0.1/>
    select distinct ?name ?publisher ?pages ?thumbnail  ?description where {{
        ?book  rdf:type  dbo:Book;
               rdfs:label ?name;
               dbo:thumbnail ?thumbnail;
               dc:publisher ?publisher;
               dbo:abstract ?description;                     
               dbo:numberOfPages ?pages
    FILTER((lang(?name)="en")&&(lang(?description)="en")&&(BOUND(?thumbnail))&&(regex(?name,"{info}")))
    }}ORDER BY ?name
    Limit 60
    """).format(info=keyInfo))
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()
    head = results["head"]["vars"]
    doc = open('templates/search.html', 'w', encoding='UTF-8')
    print('{% extends "base.html" %}\n{% block title %}电影查询{% endblock %}', file=doc)
    print('{% block head %}', file=doc)
    str1 = """<link rel="stylesheet" href="{{ url_for('static',filename='css/base.css') }}">"""
    print(str1, file=doc)
    print('{% endblock %}', file=doc)
    print('{% block main %}', file=doc)
    print('<h3>count of result:{}</h3>'.format(str(len(results["results"]["bindings"]))), file=doc)
    nameDis = []
    for result in results["results"]["bindings"]:
        if (("name" in result) & (result['name']['value'] in nameDis)):
            continue
        if ("name" in result):
            name = result['name']['value']
            nameDis.append(result['name']['value'])
        else:
            name = 'NONE'
        if ('publisher' in result):
            publisher = result["publisher"]["value"]
        else:
            producer = 'NONE'
        if ('pages' in result):
            pages = result["pages"]["value"]
        else:
            pages = 'NONE'
        if ('thumbnail' in result):
            picture = result['thumbnail']['value']
        else:
            picture = 'http://upload.wikimedia.org/wikipedia/commons/7/7a/Question_Mark.gif'
        if ('description' in result):
            description = result["description"]["value"]
        else:
            description = 'NONE'
        print('<div class="media">', file=doc)
        print('<div class="media-left media-middle">', file=doc)
        print('<a href="#"><img class="media-object" src="{}" alt="..."></a>'.format(picture), file=doc)
        print('</div>', file=doc)
        print('<div class="media-body">', file=doc)
        print('<h4 class="media-heading">{}</h4>'.format(name), file=doc)
        print('<h4 class="media-heading">publisher:{}</h4>'.format(publisher), file=doc)
        print('<h4 class="media-heading">pages:{}</h4>'.format(pages), file=doc)
        print('<h4 class="media-heading">abstract:{}</h4>'.format(description), file=doc)
        print('</div>', file=doc)
        print('</div>', file=doc)
    print('{% endblock %}', file=doc)
    doc.close()
def searchfilms(keyInfo):
    sparql = SPARQLWrapper("http://dbpedia.org/sparql")
    sparql.setQuery(("""
    prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
    prefix dbo: <http://dbpedia.org/ontology/>
    prefix dc: <http://purl.org/dc/elements/1.1/>
    prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    select distinct ?name ?producer ?runtime ?homepage  ?budget ?thumbnail  ?description where {{
    ?film       rdf:type dbo:Film;
                rdfs:label ?name;
                dbo:abstract ?description;            
                dbp:producer ?producer;            
                foaf:homepage ?homepage;
                dbo:budget ?budget;
                dbo:runtime ?runtime;
                dbo:thumbnail ?thumbnail.
    FILTER((lang(?name)="en")&&(lang(?description)="en")&&(BOUND(?homepage))&&(BOUND(?thumbnail))&&(regex(?name,"{info}")))
    }}ORDER BY DESC(?budget)
    Limit 60
    """).format(info=keyInfo))
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()
    head = results["head"]["vars"]
    doc = open('templates/search.html', 'w', encoding='UTF-8')
    print('{% extends "base.html" %}\n{% block title %}电影推荐{% endblock %}', file=doc)
    print('{% block head %}', file=doc)
    str1 = """<link rel="stylesheet" href="{{ url_for('static',filename='css/base.css') }}">"""
    print(str1, file=doc)
    print('{% endblock %}', file=doc)
    print('{% block main %}', file=doc)
    print('<h3>count of result:{}</h3>'.format(str(len(results["results"]["bindings"]))), file=doc)
    nameDis = []
    for result in results["results"]["bindings"]:
        if (("name" in result) & (result['name']['value'] in nameDis)):
            continue
        if ("name" in result):
            name = result['name']['value']
            nameDis.append(result['name']['value'])
        else:
            name = 'NONE'
        if ('producer' in result):
            producer = result["producer"]["value"]
        else:
            producer = 'NONE'
        if ('runtime' in result):
            runtime = result["runtime"]["value"]
        else:
            runtime = 'NONE'
        if ('homepage' in result):
            homepage = result["homepage"]["value"]
        else:
            homepage = 'NONE'
        if ('thumbnail' in result):
            picture = result['thumbnail']['value']
        else:
            picture = 'http://upload.wikimedia.org/wikipedia/commons/7/7a/Question_Mark.gif'
        if ('description' in result):
            description = result["description"]["value"]
        else:
            description = 'NONE'
        print('<div class="media">', file=doc)
        print('<div class="media-left media-middle">', file=doc)
        print('<a href="{}"><img class="media-object" src="{}" alt="..."></a>'.format(homepage, picture), file=doc)
        print('</div>', file=doc)
        print('<div class="media-body">', file=doc)
        print('<h4 class="media-heading">{}</h4>'.format(name), file=doc)
        print('<h4 class="media-heading">producer:{}</h4>'.format(producer), file=doc)
        print('<h4 class="media-heading">runtime:{}</h4>'.format(runtime), file=doc)
        print('<h4 class="media-heading">abstract:{}</h4>'.format(description), file=doc)
        print('</div>', file=doc)
        print('</div>', file=doc)
    print('{% endblock %}', file=doc)
    doc.close()
def searchgames(keyInfo):
    sparql = SPARQLWrapper("http://dbpedia.org/sparql")
    sparql.setQuery(("""
    prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
    prefix dbo: <http://dbpedia.org/ontology/>
    prefix dc: <http://purl.org/dc/elements/1.1/>
    prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    select distinct ?name  ?time ?compay ?link ?games ?description where {{
    ?games  rdf:type  dbo:VideoGame;
            dbo:developer ?compay;
            foaf:homepage ?link;
            dbo:abstract ?description;
            dbo:releaseDate ?time;
            rdfs:label    ?name 
    FILTER((lang(?name)="en")&&(regex(?name,"{info}"))&&(lang(?description)="en"))
    }}order by ?name
    limit 40
    """).format(info=keyInfo))
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()
    doc = open('templates/search.html', 'w', encoding='UTF-8')
    print('{% extends "base.html" %}\n{% block title %}游戏推荐{% endblock %}', file=doc)
    print('{% block head %}', file=doc)
    str1 = """<link rel="stylesheet" href="{{ url_for('static',filename='css/main.css') }}">"""
    print(str1, file=doc)
    print('{% endblock %}', file=doc)
    print('{% block main %}', file=doc)
    print('<h3>count of result:{}</h3>'.format(str(len(results["results"]["bindings"]))), file=doc)
    nameDis = []
    for result in results["results"]["bindings"]:
        # 防止检查结果重复
        if (("name" in result) & (result['name']['value'] in nameDis)):
            continue
        if ("name" in result):
             name = result['name']['value']
             nameDis.append(result['name']['value'])
        else:
             continue
        if ('description' in result):
            description = result['description']['value']
        else:
            description = 'NONE'
        if ('link' in result):
            link = result['link']['value']
        else:
            link = 'NONE'
        if ('compay' in result):
            compay = result['compay']['value']
            # # author = result['author']['value'].encode('ascii', 'ignore')
        else:
            compay = 'NONE'
        if ('time' in result):
            mytime = result['time']['value']
        else:
            mytime = 'None'
        print('<div class="jumbotron">', file=doc)
        print('<h1>{}</h1>'.format(name), file=doc)
        print('<p>Bycompany:{}</p>'.format(compay), file=doc)
        print('<p>releaseDate:{}</p>'.format(mytime), file=doc)
        print('<p>abstract:{}</p>'.format(description), file=doc)
        print('<p><a class="btn btn-primary btn-lg" href="{}" role="button">Learn more</a></p>'.format(link), file=doc)
        print('</div>'.format(description), file=doc)
    print('{% endblock %}', file=doc)
    doc.close()

def mysearch(keyInfo, typeInfo):
    if typeInfo == "1":
        searchbooks(keyInfo)
    elif typeInfo == "2":
        searchfilms(keyInfo)
    elif typeInfo == "3":
        searchgames(keyInfo)
    else:
        return "错误：请输入查询类型"