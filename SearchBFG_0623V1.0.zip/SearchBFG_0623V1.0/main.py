from flask import Flask, render_template, request, url_for, redirect, session
from mysearch import *

app = Flask(__name__)

@app.route('/')
def index():
    # 显示所有游戏信息
    return render_template('index.html')

@app.route('/search/',methods=['GET','POST'])
def search():
    if request.method == 'GET':
        render_template('search.html')
    else:
        keyInfo = request.form.get('keywords')
        typeInfo = request.form.get('type')
        # print(type(typeInfo))
        print(typeInfo, keyInfo)
        if (keyInfo == "")or(typeInfo == ""):
            return render_template('errorInfo.html')
        mysearch(keyInfo, typeInfo)
        return render_template('search.html')
@app.route('/books/')
def books():
    return render_template('books.html')
@app.route('/films/')
def films():
    return render_template('films.html')
@app.route('/games/')
def games():
    return render_template('games.html')
@app.route('/helpInfo/')
def helpInfo():
    pass
if __name__ == '__main__':
    app.run(debug=True)
