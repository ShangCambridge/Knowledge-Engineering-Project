from SPARQLWrapper import SPARQLWrapper, JSON

sparql = SPARQLWrapper("http://dbpedia.org/sparql")
sparql.setQuery("""
prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
prefix dbo: <http://dbpedia.org/ontology/>
prefix dc: <http://purl.org/dc/elements/1.1/>
prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
select distinct ?name  ?time ?compay ?link ?games ?description where {
?games  rdf:type  dbo:VideoGame;
        dbo:developer ?compay;
        foaf:homepage ?link;
        dbo:abstract ?description;
        dbo:releaseDate ?time;
        rdfs:label    ?name 
FILTER((lang(?name)="en")&&(lang(?description)="en"))
}ORDER BY DESC(?time)
LIMIT 60
""")
sparql.setReturnFormat(JSON)
results = sparql.query().convert()
doc = open('templates/games.html', 'w', encoding='UTF-8')
print('{% extends "base.html" %}\n{% block title %}推荐界面{% endblock %}', file=doc)
print('{% block head %}', file=doc)
str1 = """<link rel="stylesheet" href="{{ url_for('static',filename='css/main.css') }}">"""
print(str1, file=doc)
print('{% endblock %}', file=doc)
print('{% block main %}', file=doc)
print('<h3>{}推荐</h3>'.format("游戏"), file=doc)
# print('<h3>count of result:{}</h3>'.format(str(len(results["results"]["bindings"]))), file=doc)
nameDis = []
for result in results["results"]["bindings"]:
    # 防止检查结果重复
    if (("name" in result) & (result['name']['value'] in nameDis)):
        continue
    if ("name" in result):
         name = result['name']['value']
         nameDis.append(result['name']['value'])
    else:
         continue
    if ('description' in result):
        description = result['description']['value']
    else:
        description = 'NONE'
    if ('link' in result):
        link = result['link']['value']
    else:
        link = 'NONE'
    if ('compay' in result):
        compay = result['compay']['value']
    else:
        compay = 'NONE'
    if ('time' in result):
        mytime = result['time']['value']
    else:
        mytime = 'None'
    print('<div class="jumbotron">', file=doc)
    print('<h1>{}</h1>'.format(name), file=doc)
    print('<p>Bycompany:{}</p>'.format(compay), file=doc)
    print('<p>releaseDate:{}</p>'.format(mytime), file=doc)
    print('<p>abstract:{}</p>'.format(description), file=doc)
    print('<p><a class="btn btn-primary btn-lg" href="{}" role="button">Learn more</a></p>'.format(link), file=doc)
    print('</div>'.format(description), file=doc)
print('{% endblock %}', file=doc)
doc.close()